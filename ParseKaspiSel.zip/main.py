import asyncio
import datetime
import json
import math
import urllib3
import certifi
import os
from sys import argv
import re
import time
from pathlib import Path
from platform import system
from urllib.parse import urlparse
from multiprocessing import Pool
import pandas as pd
import requests
import seleniumwire.undetected_chromedriver as uc
from bs4 import BeautifulSoup
from pandas import ExcelWriter
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from seleniumwire import webdriver
from seleniumwire.utils import decode
from webdriver_manager.chrome import ChromeDriverManager

if system() == "Windows":
    exec_path = str(Path.cwd() / 'driver' / 'chromedriver.exe')
elif system() == "Linux":
    exec_path = str(Path.cwd() / 'driver' / 'chromedriver')
options = Options()
options.add_argument("--headless")
options.add_argument("--ignore-certificate-errors")
options.add_argument('--no-default-browser-check')
options.add_argument('--no-first-run')
options.add_argument('--disable-gpu')
options.add_argument('--disable-extensions')
options.add_argument('--disable-default-apps')
# options.add_experimental_option("excludeSwitches", ["enable-automation"])
# options.add_experimental_option('useAutomationExtension', False)
options.add_argument("--disable-blink-features=AutomationControlled")

swoptions = {
    'enable_har': True  # Capture HAR data, retrieve with driver.har
}
all_pages = []
all_cards = []
bot_result = []


# def interceptor(request):
#     # Block PNG, JPEG and GIF images
#     if '.jpg' in request.path:
#         request.abort()
async def get_brand_pages(brand, city_):
    options_ = Options()
    options_.add_argument("--headless")
    options_.add_argument("--ignore-certificate-errors")
    options_.add_argument('--no-default-browser-check')
    options_.add_argument('--no-first-run')
    options_.add_argument('--disable-gpu')
    options_.add_argument('--disable-extensions')
    options_.add_argument('--disable-default-apps')
    # options.add_experimental_option("excludeSwitches", ["enable-automation"])
    # options.add_experimental_option('useAutomationExtension', False)
    options_.add_argument("--disable-blink-features=AutomationControlled")

    swoptions_ = {
        'enable_har': True,  # Capture HAR data, retrieve with driver.har
        # 'request_storage': 'memory',  # Store requests and responses in memory only
        'auto_config': True,
        # 'request_storage_max_size': 100,
        'request_storage_base_dir': './data'
    }
    driver = webdriver.Chrome(options=options_, seleniumwire_options=swoptions_,
                              service=Service(ChromeDriverManager().install()))
    driver.scopes = ['.*kaspi.*']
    # driver.request_interceptor = interceptor
    driver.get('https://kaspi.kz/shop/')
    driver.find_element(By.XPATH, '//a[@data-city-id=' + city_ + ']').click()
    driver.get(brand['url'])
    time.sleep(10)
    print('start0')

    try:
        element_present = EC.presence_of_element_located((By.CLASS_NAME, 'pagination'))
        WebDriverWait(driver, 60).until(element_present)
        elements = driver.find_elements(By.CLASS_NAME, 'pagination__el')
        elements[len(elements) - 1].click()
        time.sleep(10)
        driver.refresh()
        time.sleep(10)
        # del driver.requests
    except TimeoutException:
        print("Timed out waiting for page to load")
        driver.quit()
        return False
    print('start1')
    try:
        element_present = EC.presence_of_element_located((By.CLASS_NAME, 'pagination'))
        WebDriverWait(driver, 60).until(element_present)
        elements = driver.find_elements(By.CLASS_NAME, 'pagination__el')
        elements[1].click()
        time.sleep(5)
    except TimeoutException:
        print("Timed out waiting for page to load")
        driver.quit()
        return False
    # time.sleep(5)

    # time.sleep(3)
    first = True
    count_p = 1
    pages = math.ceil(get_pag_count(driver.page_source) / 12)
    try:
        request = driver.wait_for_request('/yml/product-view/pl/results', 30)
    except TimeoutException:
        print("Timed out waiting for page to load")
        driver.quit()
        return False
    http = urllib3.PoolManager(ca_certs=certifi.where())

    rurl = request.url
    for page_ in range(pages):
        try:
            print('page' + str(brand['q'].replace('%3AmanufacturerName%3A', '')))
            newurl = rurl.replace('page=1', 'page=' + str(page_))
            resp = http.request('GET', newurl, headers=dict(request.headers))
            body = resp.data.decode(encoding='utf-8')
            # Load the JSON
            print(count_p)
            data = json.loads(body, )['data']
            for card in data:
                print('card data' + str(count_p) + ' card ' + card['title'])
                all_cards.append(card)
                count_p += 1
        except TimeoutException:
            print("Timed out waiting for page to load")
            driver.quit()
            return False

    # pd.DataFrame(all_pages).to_csv('all_pages.csv',encoding='utf-8', index=False)
    del driver.requests
    driver.close()
    return True


def get_pag_count(ps):
    soup = BeautifulSoup(ps, 'lxml')
    pag = soup.find('span', class_='filters__count')
    numbers = re.findall(r'\b\d+\b', pag.getText())
    return int(numbers[0])


async def main(url_, city_):
    print(url_)
    driver = webdriver.Chrome(options=options, seleniumwire_options=swoptions,
                              service=Service(ChromeDriverManager().install())
                              )
    driver.scopes = ['.*kaspi.*']
    driver.get('https://kaspi.kz/shop')
    driver.find_element(By.XPATH, '//a[@data-city-id=' + city_ + ']').click()
    driver.get(url_)
    time.sleep(10)
    # get brands
    brands_links = []
    filters = driver.find_elements(By.CLASS_NAME, 'filters__filter')
    filters[2].find_element(By.CLASS_NAME, 'filters__spoiler').click()
    time.sleep(3)
    filters = driver.find_elements(By.CLASS_NAME, 'filters__filter')
    brandwraper = filters[2].find_elements(By.CLASS_NAME, 'filters__filter-wrapper')
    brandslice = brandwraper[0].find_elements(By.CLASS_NAME, 'filters__filter-row__description')

    for row in brandslice:
        dict_brand = dict(url='', count='', q='')
        namefilter = row.find_element(By.CLASS_NAME, 'filters__filter-row__description-label').text
        count_brand = row.find_element(By.CLASS_NAME, 'filters__count').text
        count_brand = re.findall(r'\b\d+\b', count_brand)[0]
        f = url_.find('%3A')
        dict_brand['url'] = url_[:f] + '%3AmanufacturerName%3A' + namefilter.replace(' ', '%20') + url_[47:]
        dict_brand['count'] = count_brand
        dict_brand['q'] = '%3AmanufacturerName%3A' + namefilter.replace(' ', '%20')
        brands_links.append(dict_brand)
    new_brand_links = []
    # stak 12
    f = url_.find('%3A')
    stak_dict = dict(url=url_[:f], count='', q='')
    stak_count = 0
    stak_q = ''
    for br in brands_links:
        if int(br['count']) < 14:
            stak_count = stak_count + int(br['count'])
            stak_q = stak_q + br['q']
        else:
            new_brand_links.append(br)
    stak_dict['url'] = stak_dict['url'] + stak_q + url_[47:]
    stak_dict['count'] = str(stak_count)
    stak_dict['q'] = stak_q
    print(stak_dict)
    new_brand_links.append(stak_dict)
    pd.DataFrame(new_brand_links).to_csv('out.csv', index=False)
    driver.quit()

    for br in new_brand_links:
        print('Start ' + str(br['q'].replace('%3AmanufacturerName%3A', '')))
        done = False
        while not done:
            done = await get_brand_pages(br, city_)

    driver.quit()


def compare(a, b):
    if a > b:
        return f'Дороже нас', a - b
    elif a < b:
        return f'Дешевле нас', a - b
    else:
        return 'Как мы', 0


def get_offers(all_cards_, merchantId, cityId):
    count_card = 1
    for sku in all_cards_:
        print(count_card)
        try:
            print('Start ' + sku['title'])
            headers_price_competition = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:104.0) Gecko/20100101 Firefox/104.0',
                'Accept': 'application/json, text/*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Content-Type': 'application/json; charset=utf-8',
                'Origin': 'https://kaspi.kz',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Referer': sku['shopLink']
            }

            pre_data = {"cityId": cityId, "id": sku['id'], "merchantUID": "", "limit": 25, "page": 0,
                        "sort": True}
            data_price_competition = json.dumps(pre_data, indent=4)

            url_price_competition = "https://kaspi.kz/yml/offer-view/offers/" + str(sku['id']) + "?PageSpeed=noscript"
            response_price_competition = requests.post(url_price_competition, headers=headers_price_competition,
                                                       data=data_price_competition)
            print(response_price_competition)
            info_competition = response_price_competition.json()['offers']
            print('done' + sku['title'])
            k = 1
            we_in = [off['merchantId'] for off in info_competition]
            if merchantId in we_in:
                we_in = info_competition[we_in.index(merchantid)]['price']
            else:
                we_in = None

            for offer in info_competition:
                try:
                    infos = {
                        'Код товара': sku['id'],
                        'Наименование': sku['title'],
                        'URL': sku['shopLink'],
                        'Brand': sku['brand']
                    }
                    cat = sku['category'].replace('[', '')
                    cat = cat.replace(']', '')
                    cat = cat.replace(',', ';', 2)
                    cat = cat.replace("'", '')
                    category = cat.split(';')
                    print(category)
                    if len(category) >= 3:
                        infos['Категория 1'] = category[0]
                        infos['Категория 2'] = category[1]
                        infos['Категория 3'] = category[2]
                    elif len(category) == 2:
                        infos['Категория 1'] = category[0]
                        infos['Категория 2'] = category[1]
                        infos['Категория 3'] = ''
                    elif len(category) == 1:
                        infos['Категория 1'] = category[0]
                        infos['Категория 2'] = ''
                        infos['Категория 3'] = ''
                    else:
                        infos['Категория 1'] = ''
                        infos['Категория 2'] = ''
                        infos['Категория 3'] = ''
                    infos['Продавец'] = offer['merchantName']
                    infos['Цена'] = offer['price']
                    infos['Дата самовывоза'] = 'Есть' if 'pickup' in offer else 'Нет'
                    infos['Доставка дата'] = offer['delivery'].split('T')[0] if 'delivery' in offer else 'Нет'
                    infos['Доставка цена'] = 'Бесплатно'
                    infos['Позиция'] = k
                    if offer['merchantId'] != merchantid:
                        if we_in:
                            a, b = compare(offer['price'], we_in)
                            infos['Сравнение цен'] = a
                            infos['Разница'] = b
                        else:
                            infos['Сравнение цен'] = 'Нас нет'
                            infos['Разница'] = 0.0
                    else:
                        infos['Сравнение цен'] = 'Это мы'
                        infos['Разница'] = 0.0
                    k += 1
                    bot_result.append(infos)

                except Exception as ex:
                    print(ex)
                    return False
            count_card += 1
        except Exception as ex:
            print(ex)
            return False
    return True


if __name__ == '__main__':

    if len(argv) < 5:
        print('Ошибка вызывайте программу в формате python main.py city merchantid url  task')
        quit()
    city = argv[1]  #
    url = argv[3]
    merchantid = argv[2]
    task = argv[4]
    dirres = os.makedirs('./results/' + task, exist_ok=True)
    print(dirres)
    url = url + '&c=' + city
    print(argv[3])
    url = url.replace('&sc=', '')
    asyncio.run(main(url, city))
    ac = pd.DataFrame(all_cards)
    writer = pd.ExcelWriter('all_cards.xlsx', engine='xlsxwriter')
    ac.to_excel(writer, 'Sheet1', index=False)
    writer.close()
    x1 = pd.ExcelFile('all_cards.xlsx')
    dfcsv = x1.parse("Sheet1")
    all_cards = dfcsv.to_dict('records')
    finish = False
    while not finish:
        finish = get_offers(all_cards, merchantid, city)

    df = pd.DataFrame(bot_result)
    # print(df)
    writer = pd.ExcelWriter('./results/' + task+'/merchantid_' + datetime.datetime.now().strftime("%m_%d_%Y_%H_%M") + '.xlsx',
                            engine='xlsxwriter')
    df.to_excel(writer, 'Sheet1', index=False)
    writer.close()
